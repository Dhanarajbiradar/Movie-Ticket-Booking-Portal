# Online-Movie-Ticket-Booking-Portal
### Java Project - Servlets, JSP, HTML, MySQL
<br />
A Web App for Online Booking of Movie Tickets. Consist of Modules: <br />
Theatre <br />
User <br />
Admin <br />
Transaction <br />
<br />
A Show consist of a Screen and a Timeslot. A User can Book a ticket for any Movie for a corresponding Timeslot it is showed in. Also the Theatre has different categories of seat i.e, Silver, Gold and Platinum. All the Screens have different Capacity.<br />
<br />
An Admin can Insert Movie, Schedule a Movie in a particular Screen and in particular Timeslot and can delete a Movie.
<br/>
After Booking the user is shown the Total Amount of the tickets also he is given the option to Order a Meal. If the User orders the Meal User is shown the Total amount i.e, Tickets + Food.
<br />
It is a Project based on Object Oriented Concepts. Interfaces, Inheritence, JDBC, Servlets, JSP Concepts of Java are used. MySQL is used for Database.
