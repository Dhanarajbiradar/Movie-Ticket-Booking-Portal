
interface timeslot1{
	int startTime = 9;
	int endTime = 1;
}

interface timeslot2{
	int startTime = 1;
	int endTime = 5;
}

interface timeslot3{
	int startTime = 5;
	int endTime = 9;
}